<?php

namespace App\Controllers;
use App\Models\EmployeeModel;

class Employee extends BaseController
{


    public function index(): string
    {
        return view('employee');
    }


  public function showemployee($id){
   
    $employeeObj = new EmployeeModel();
    $employee= $employeeObj->find($id);
    return view("employee_details",['employee'=>$employee]);

  }
  
   public function listEmployees(){
   
    $employeesObj = new EmployeeModel();
   $employees= $employeesObj->findAll();
   return view("employee_list",['employees'=>$employees]);

   }
     public function update($uid){
   
       $file = $this->request->getFile("editProfile_picture");
       $fileError = $file->getError() ;
       $imagePath = "";
        if($fileError ==0){
            $fileName = $file->getRandomName();
             $file->move(FCPATH.'uploads',$fileName);
    
             $imagePath = base_url('uploads/' . $fileName);
        }else {
          
            $imagePath = $this->request->getPost("old_image_path");
        }
        $dataToUpdate = [
            'name' => $this->request->getPost("editName"),
            'address'=> $this->request->getPost("editAddress"),
            'designation'=> $this->request->getPost("editDesignation"),
            'salary'=> $this->request->getPost("editSalary"),
            "profile_picture"=>$imagePath
        ];
        $employeesObj = new EmployeeModel();
        $employeesObj->update($uid,$dataToUpdate);
        $message = (!empty($employeesObj)) ? "update_success":"update_error";
        return redirect()->to("/employee/list")->withInput()->with("message",$message);

       
    }
     public function delete($id){
    
        $employeesObj = new EmployeeModel();
        $employeesObj->delete($id);
        $message = (!empty($employeesObj)) ? "delete_success":"delete_error";
        return redirect()->to("/employee/list")->withInput()->with("message",$message);

    }

      public function submit(){
    
  
     helper(['form']);
     $rules = [
       'name' => [
        'rules' => 'required|regex_match[/^[A-Za-z ]{3,15}$/]',
        'errors' => [
            'required' => 'Name field is required',
            'regex_match' => 'Name must be 3 to 15 characters and only letters, numbers, comma, dot, space allowed'
        ]
    ],
    'address' => [
        'rules' => 'required|regex_match[/^[A-Za-z0-9 ,.\-]{3,50}$/]',
        'errors' => [
            'required' => 'Address is required',
            'regex_match' => 'Address must be 3 to 15 characters and only letters, numbers, comma, dot, space allowed'
        ]
    ],
    'designation' => [
        'rules' => 'required|regex_match[/^[A-Za-z ]{3,15}$/]',
        'errors' => [
            'required' => 'Designation is required',
            'regex_match' => 'Designation must contain only letters and spaces'
        ]
    ],
    'salary' => [
        'rules' => 'required|regex_match[/^[0-9]+(\.[0-9]{1,2})?$/]',
        'errors' => [
            'required' => 'Salary is required',
            'regex_match' => 'Salary must be a valid number'
        ]
        ],
   
     ];

     if(!$this->validate($rules)){
     return redirect()
              ->back()
              ->withInput()
              ->with("validation",$this->validator)
              ;


     }else{
    $id = "emp-".rand(1000,9999).'-'.time();
    $name = $this->request->getPost('name');
    $address = $this->request->getPost('address');
    $designation = $this->request->getPost('designation');
    $salary = $this->request->getPost('salary');
    $file = $this->request->getFile('profile_picture');
     $fileName = $file->getRandomName();
    $file->move(FCPATH.'uploads',$fileName);
    
    $imagePath = base_url('uploads/' . $fileName);
    $data=[
      'id' => $id,
      'name' => $name,
      'address' => $address,
      'designation' => $designation,
      'salary' => $salary,
      'profile_picture'=>$imagePath
    ];

     $employeeObj = new EmployeeModel();
      $employeeObj->insert($data);
       $message = (!empty($employeeObj)) ? "signup_success" : "signup_error";
    return redirect()->to("/employee")->withInput()->with("message",$message);
     
  }
  }
}
