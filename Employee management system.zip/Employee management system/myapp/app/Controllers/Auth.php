<?php

namespace App\Controllers;

use App\Models\AuthModel;


class Auth extends BaseController
{
    public function index()
    {
       
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/employee/list');
        }

        return view('login');
    }

    public function attempt()
    {
        helper(['form']);

        $rules = [
            'name'      => 'required',
            'user_name' => 'required',
            'password' => 'required'
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $username = $this->request->getPost('user_name');
        $password = $this->request->getPost('password');
        $name = $this->request->getPost('name');
        
        $loginModel = new AuthModel();
        $user = $loginModel->where('user_name', $username)->first();

        if ($user && password_verify($password, $user['password'])) {
            
            session()->set([
                'user_id'    => $user['id'],
                'user_name'  => $user['user_name'],
                'display_name' => $user['name'],
                'isLoggedIn' => true
            ]);
            session()->setFlashdata('success', 'Welcome, '.$user['name'].'!');
            return redirect()->to('/employee/list');
        } else {
           
            return redirect()->back()->with('error', 'Invalid username or password');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/')->with('success', 'You have logged out successfully.');
    }
}