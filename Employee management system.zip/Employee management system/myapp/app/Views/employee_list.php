<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee List</title>


  <link
    rel="stylesheet"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body class="bg-light">


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <a class="navbar-brand font-weight-bold" href="#">Employee System</a>
    <div class="ml-auto d-flex align-items-center">
      <?php if (session()->get('isLoggedIn')) { ?>
        <span class="text-white mr-3">
          Welcome, <strong><?php echo (session()->get('display_name')) ?></strong>
        </span>
        <a href="<?php echo site_url('logout') ?>" class="btn btn-danger btn-sm">
          Logout
        </a>
      <?php } ?>
    </div>

  </nav>

  <div class="container mt-5">


    <?php if (session()->getFlashdata("message")): ?>
      <?php
      $msg = session()->getFlashdata("message");
      $alert = "info";
      if ($msg == "update_success") $alert = "success";
      elseif ($msg == "update_error") $alert = "danger";
      elseif ($msg == "delete_success") $alert = "warning";
      elseif ($msg == "delete_error") $alert = "danger";
      ?>
      <div class="alert alert-<?= $alert ?> text-center">
        <?= ucfirst(str_replace("_", " ", $msg)); ?>
      </div>
    <?php endif; ?>


    <div class="card shadow-sm">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Employee List</h5>

        <a href="<?php echo base_url('employee') ?>" class="btn btn-light btn-sm">
          ➕ Add Employee
        </a>
      </div>
      <div class="card-body">
        <?php if (!empty($employees)) { ?>
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark text-center">
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Designation</th>
                  <th>Salary</th>
                  <th>Profile Picture</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1;
                foreach ($employees as $employee) { ?>
                  <tr class="text-center">
                    <td><?php $i++ ?></td>
                    <td><?php echo ($employee['name']) ?></td>
                    <td><?php echo ($employee['address']) ?></td>
                    <td><?php echo ($employee['designation']) ?></td>
                    <td>₹<?php echo ($employee['salary']) ?></td>
                    <td>
                      <img src="<?php echo ($employee['profile_picture']) ?>"
                        alt="<?php echo ($employee['name']) ?>"
                        class="img-thumbnail"
                        style="height:80px;width:80px;object-fit:cover;">
                    </td>
                    <td>
                      <a href="<?php echo site_url('employee/showemployee/' . $employee['id']) ?>"
                        class="btn btn-info btn-sm">View</a>
                      <a href="<?php echo site_url('employee/delete/' . $employee['id']) ?>"
                        onclick="return confirm('Are you sure to delete this employee?');"
                        class="btn btn-danger btn-sm">Delete</a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        <?php } else { ?>
          <p class="text-center text-muted mb-0">No employees found.</p>
        <?php } ?>
      </div>
    </div>


  </div>


  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>