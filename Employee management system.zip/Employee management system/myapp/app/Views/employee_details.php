<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Employee</title>

  
  <link rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
   
      <a class="navbar-brand font-weight-bold" href="#">Employee System</a>
      <div class="ml-auto d-flex align-items-center">
        <?php if(session()->get('isLoggedIn')){ ?>
          <span class="text-white mr-3">
             Welcome, <strong><?php echo(session()->get('display_name')) ?></strong>
          </span>
          <a href="<?php echo site_url('logout') ?>" class="btn btn-danger btn-sm">
            Logout
          </a>
        <?php } ?>
      </div>
   
  </nav>

  <div class="container mt-5">
    <?php if (!empty($employee)) { ?>
      <div class="card shadow-lg border-0">
        <div class="card-header bg-primary text-white text-center">
          <h4>Edit Employee Details</h4>
        </div>

        <div class="card-body">
          <form method="POST"
                enctype="multipart/form-data"
                action="<?= site_url('employee/update/'.$employee['id']) ?>">
            <?= csrf_field() ?>

            <div class="form-group">
              <label for="editName">Name</label>
              <input type="text"
                     name="editName"
                     id="editName"
                     class="form-control"
                     value="<?= esc($employee['name']) ?>"
                     required>
            </div>

            <div class="form-group">
              <label for="editAddress">Address</label>
              <input type="text"
                     name="editAddress"
                     id="editAddress"
                     class="form-control"
                     value="<?= esc($employee['address']) ?>"
                     required>
            </div>

            <div class="form-group">
              <label for="editDesignation">Designation</label>
              <input type="text"
                     name="editDesignation"
                     id="editDesignation"
                     class="form-control"
                     value="<?= esc($employee['designation']) ?>"
                     required>
            </div>

            <div class="form-group">
              <label for="editSalary">Salary</label>
              <input type="number"
                     name="editSalary"
                     id="editSalary"
                     class="form-control"
                     value="<?= esc($employee['salary']) ?>"
                     required>
            </div>

            <div class="form-group">
              <label>Current Profile Picture</label><br>
              <img src="<?= esc($employee['profile_picture']) ?>"
                   alt="Profile Picture"
                   class="img-thumbnail mb-2"
                   style="width:120px;height:120px;object-fit:cover;">
              <input type="file"
                     name="editProfile_picture"
                     class="form-control-file border p-2 rounded">
              <input type="hidden"
                     name="old_image_path"
                     value="<?= esc($employee['profile_picture']) ?>">
            </div>

            <div class="text-center mt-4">
              <button type="submit" class="btn btn-success px-4 mr-2">Update</button>
              <a href="<?= site_url('employee/delete/'.$employee['id']) ?>"
                 class="btn btn-danger px-4"
                 onclick="return confirm('Do you want to delete this employee?');">
                 Delete
              </a>
              <a href="<?= site_url('employee/list') ?>" class="btn btn-secondary px-4 ml-2">Back</a>
            </div>
          </form>
        </div>
      </div>
    <?php } else { ?>
      <div class="alert alert-warning text-center mt-5">
        No employee data found.
      </div>
    <?php } ?>
  </div>

  
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
