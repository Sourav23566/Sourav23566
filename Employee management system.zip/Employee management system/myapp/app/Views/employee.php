<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Employee</title>


  <link rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
   
      <a class="navbar-brand font-weight-bold" href="#">Employee System</a>
      <div class="ml-auto d-flex align-items-center">
        <?php if(session()->get('isLoggedIn')){ ?>
          <span class="text-white mr-3">
             Welcome, <strong><?php echo(session()->get('display_name')) ?></strong>
          </span>
          <a href="<?php echo site_url('logout') ?>" class="btn btn-danger btn-sm">
            Logout
          </a>
        <?php } ?>
      </div>
   
  </nav>

  <div class="container mt-5">
    <div class="card shadow-lg border-0">
      <div class="card-header bg-primary text-white text-center">
        <h4>Add New Employee</h4>
      </div>

      <div class="card-body">
   
        <?php if(session()->getFlashdata("message")=="signup_success"){ ?>
          <div class="alert alert-success text-center"> Employee Added Successfully!</div>
        <?php } elseif(session()->getFlashdata("message")=="signup_error"){ ?>
          <div class="alert alert-danger text-center"> Unable to Add Employee!</div>
        <?php } ?>

        <form method="POST"
              enctype="multipart/form-data"
              action="<?= site_url('employee/submit') ?>">
          <?= csrf_field() ?>

        
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text"
                   class="form-control"
                   id="name"
                   name="name"
                   
                   placeholder="Enter employee name">
            <small class="text-danger">
              <?php echo session()->getFlashdata('validation') ? session()->getFlashdata('validation')->showError('name') : '' ?>
            </small>
          </div>

     
          <div class="form-group">
            <label for="address">Address</label>
            <input type="text"
                   class="form-control"
                   id="address"
                   name="address"
                   
                   placeholder="Enter employee address">
            <small class="text-danger">
              <?php echo session()->getFlashdata('validation') ? session()->getFlashdata('validation')->showError('address') : '' ?>
            </small>
          </div>

        
          <div class="form-group">
            <label for="designation">Designation</label>
            <input type="text"
                   class="form-control"
                   id="designation"
                   name="designation"
                  
                   placeholder="Enter designation">
            <small class="text-danger">
              <?php echo session()->getFlashdata('validation') ? session()->getFlashdata('validation')->showError('designation') : '' ?>
            </small>
          </div>

        
          <div class="form-group">
            <label for="salary">Salary</label>
            <input type="number"
                   class="form-control"
                   id="salary"
                   name="salary"
                  
                   placeholder="Enter salary">
            <small class="text-danger">
              <?php echo session()->getFlashdata('validation') ? session()->getFlashdata('validation')->showError('salary') : '' ?>
            </small>
          </div>

          
          <div class="form-group">
            <label for="profile_picture">Upload Profile Picture</label>
            <input type="file"
                   class="form-control-file"
                   id="profile_picture"
                   name="profile_picture"
                   onchange="loadImage(event)">
            <div id="preview" class="mt-3 text-center"></div>
          </div>

          <div class="text-center mt-4">
            <button type="submit" class="btn btn-success px-4">Submit</button>
            <a href="<?= site_url('employee/list') ?>" class="btn btn-secondary px-4 ml-2">Back to List</a>
          </div>
        </form>
      </div>
    </div>
  </div>


  <script>
    function loadImage(event) {
      const file = event.target.files[0];
      if (file) {
        const imageBlob = URL.createObjectURL(file);
        document.getElementById('preview').innerHTML =
          `<img src="${imageBlob}" class="img-thumbnail mt-2" style="height:200px;width:200px;object-fit:cover;">`;
      }
    }
  </script>

  
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
