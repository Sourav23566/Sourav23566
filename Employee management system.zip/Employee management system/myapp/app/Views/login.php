<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

  <div class="container">
    <div class="row justify-content-center align-items-center" style="height:100vh;">
      <div class="col-12 col-md-6 col-lg-4">
        <div class="card shadow-lg">
          <div class="card-header bg-primary text-white text-center">
            <h4 class="mb-0">Login</h4>
          </div>
          <div class="card-body">

            
            <?php if(session()->getFlashdata('success')){ ?>
              <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php } ?>

            <?php if(session()->getFlashdata('error')){ ?>
              <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php } ?>

            <?php if(isset($validation)){ ?>
              <div class="alert alert-danger"><?= $validation->listErrors() ?></div>
            <?php } ?>

           
            <form method="post" action="<?= site_url('login/attempt') ?>">
             

              <div class="form-group">
                <label for="user_name">Username</label>
                <input type="text"
                       class="form-control"
                       name="user_name"
                       id="user_name"
                       value="<?php echo old('user_name') ?>"
                       placeholder="Enter username"
                       required>
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password"
                       class="form-control"
                       name="password"
                       id="password"
                       placeholder="Enter password"
                       required>
              </div>
                <div class="form-group">
                <label for="name">Name</label>
                <input type="text"
                       class="form-control"
                       name="name"
                       id="name"
                       value="<?php echo old('user_name') ?>"
                       placeholder="Enter username"
                       required>
              </div>

              <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>

            <div class="mt-3 text-center">
              <small class="text-muted">Forgot your password? Contact admin.</small>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

  
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
