<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index')
use App\Controllers\Auth;
$routes->get('/', 'Auth::index');
$routes->post('login/attempt', 'Auth::attempt');
$routes->get('logout', 'Auth::logout');
use App\Controllers\Employee;

$routes->group('employee', ['filter' => 'auth'], function($routes) {
    $routes->get('/', 'Employee::index');
    $routes->post('submit', 'Employee::submit');
    $routes->get('list', 'Employee::listEmployees');
    $routes->get('showemployee/(:any)', 'Employee::showemployee/$1');
    $routes->post('update/(:any)', 'Employee::update/$1');
    $routes->get('delete/(:any)', 'Employee::delete/$1');
});