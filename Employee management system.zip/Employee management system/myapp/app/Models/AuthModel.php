<?php

namespace App\Models;

use CodeIgniter\Model;

class AuthModel extends Model
{
    protected $table            = 'login_details';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
     protected $allowedFields = ['user_name','password','name'];
    protected $returnType = 'array';
   
}
