<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table            = 'emp_details';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = false;
    protected $allowedFields  = ['name', 'address', 'designation', 'salary', 'profile_picture'];

   
}
