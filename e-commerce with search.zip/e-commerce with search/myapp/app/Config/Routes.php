<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\Signup;
/**
 * @var RouteCollection $routes
 */
  $routes->get('/', 'Signup::index');

$routes->post('/signup/submit', 'Signup::submit');
$routes->get('/login','Signup::login');
$routes->post('login/auth','Signup::authlogin');
$routes->get('/logout','Signup::logout');
 $routes->get('/home', 'Home::index'); 
  $routes->get('/products/fetchAll', 'Home::fetchAll'); 
 $routes->get('/products/fetchOne/(:num)', 'Home::fetchOne/$1'); 
$routes->post('/search/fetch', 'Home::search');
