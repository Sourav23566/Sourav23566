<!DOCTYPE html>
<html>
<head>
    <title>Home - E-commerce</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</head>
<body>

   
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#">E-commerce</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active"><a class="nav-link" href="#">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <a href="<?= base_url('/logout'); ?>" class="btn btn-outline-danger">Logout</a>
        </form>
      </div>
    </nav>

    <div class="container mt-4">
        <h2 class="mb-4">Our Products</h2>
        <div class="row" id="productList">
        
        </div>
    </div>

    <script>
    $(document).ready(function(){
        fetchProducts();

        function fetchProducts(){
            $.ajax({
                url: "http://localhost:8080/home",  
                type: "GET",
                dataType: "json",
                success: function(data){
                    let html = "";
                    if(data.length > 0){
                        data.forEach(function(p){
                            html += `
                            <div class="col-md-4 mb-3">
                                <div class="card h-100 shadow-sm">
                                    ${p.pro_image 
                                        ? `<img src="/uploads/${p.pro_image}" class="card-img-top" height="200">` 
                                        : `<img src="https://via.placeholder.com/200" class="card-img-top">`}
                                    <div class="card-body">
                                        <h5 class="card-title">${p.pro_name}</h5>
                                        <p class="card-text">${p.pro_desc}</p>
                                        <p><strong>₹${p.price}</strong></p>
                                        <button class="btn btn-primary viewBtn" data-id="${p.pro_id}">
                                            View Details
                                        </button>
                                    </div>
                                </div>
                            </div>`;
                        });
                    } else {
                        html = "<p class='text-center w-100'>No products available</p>";
                    }
                    $("#productList").html(html);
                }
            });
        }
    });
    </script>

</body>
</html>
