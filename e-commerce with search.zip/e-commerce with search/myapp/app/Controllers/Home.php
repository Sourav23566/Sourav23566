<?php

namespace App\Controllers;
use App\Models\UserModel;
use App\Models\ProductModel;

class Home extends BaseController
{
    public function index()
    {
        if (!session()->get('islogedin')) {
            return redirect()->to('/login');
        }
        return view('home');
    }  
 public function fetchAll(){
     $model = new ProductModel();
        // $data['products'] = $model->findAll();
        // print_r($data);
         $searchKeyword = $this->request->getGet('search');
    
    if ($searchKeyword) {
        $data['products'] = $model->search($searchKeyword); // Search for products
    } else {
        $data['products'] = $model->findAll(); // Fetch all products
    }
       

         return $this->response->setJSON($data);
        //  return view('home/index', $data);
 }
public function fetchOne($pro_id = null)
{
    $model = new ProductModel();
    $product = $model->find($pro_id);
    return $this->response->setJSON($product); 
}


   
}