<?php

namespace App\Controllers;
use App\Models\UserModel;



class Signup extends BaseController
{
    public function index()
    {
              
      return view('signup');
   }

    public function submit(){
     
 
       helper(['form']);
       

       $rules=[ 
        'name'=>[
          'rules'=>'required|min_length[3]|max_length[20]'],
        'email' =>[
          'rules'=>'required|valid_email|is_unique[user.email]',],
       'mobile'=>[
    'rules'=>'required|regex_match[/^[6-9]\d{9}$/]',
    'errors' => [
        'regex_match' => 'Please enter a valid Indian phone number.',
    ]


        ],
         
        'password'=>[ 'rules' => 'required|regex_match[/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/]',
                'errors' => [
                    'required' => 'Password is required.',
                    'regex_match' => 'Password must be at least 8 characters and include uppercase, lowercase, number, and special character.']

        ]
       ];
    
       if(!$this->validate($rules)){
           return redirect()->back()->withInput()->with('validation', $this->validator);
       }
       else{
           $name= $this->request->getPost('name');
      $email= $this->request->getPost('email');
      $mobile= $this->request->getPost('mobile');
      $password=$this->request->getPost('password');
      

      $data=[
        'user_id' => "user-".rand(1000,9999)."-".time(),
        'name' => $name,
        'email' => $email,
        'mobile'=> $mobile,
        'password' => $password
        // password_hash($password,PASSWORD_BCRYPT),
       
    ];
   

 
    $userModel = new UserModel();
      //  $userModel->insert($data);
       
      //   $message =(!empty($userModel))? "signup_success" : "signup_error";
      // return redirect()->to('/login')->withInput()->with('message',$message);
    if ($userModel->insert($data)) {
    return redirect()->to('/login')->with('message', 'signup_success');
} else {
    return redirect()->back()->withInput()->with('message', 'signup_error');
}

       }
       }


      public function login(){
        return view('login');
      }

      public function authlogin(){
        $session=session();
        $userModel = new UserModel();

        $email= $this->request->getvar('email');
        $password= $this->request->getvar('password');
        $user=$userModel->where('email',$email)->first();
//         echo 'Input Password: ' . $password . '<br>';
// echo 'Hashed Password: ' . $user['password'];
// exit;
// var_dump($password);
// var_dump($user['password']);
// var_dump(password_verify($password, $user['password']));
// exit;
        if($user){
          // if(password_verify($password,$user['password'])){
           if ($password === $user['password']) {
            $session->set([
              'user_id'=>$user['user_id'],
              'name'=>$user['name'],
              'email'=>$user['email'],
              'islogedin'=>true


            ]);
            return redirect()->to('/home');

          }
          else{
          return redirect()->back()->with('error' ,'wrong password');
          }

        }else{
          return redirect()->back()->with('error','User not found');

        }



      }

      public function logout(){
        session()->destroy();
        return redirect()->to('login');
      }
}
