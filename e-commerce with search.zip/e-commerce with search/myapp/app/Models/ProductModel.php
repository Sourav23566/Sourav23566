<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table            = 'products';
    protected $primaryKey       = 'pro_id';
    protected $useAutoIncrement = true;
    protected $allowedFields  = ['pro_id','pro_name','pro_desc','price','image'];

    public function search($keyword)
{
    return $this->db->table('products')
                    ->like('pro_name', $keyword)
                    ->orLike('pro_desc', $keyword)
                    ->get()
                    ->getResultArray();
}
    
}
