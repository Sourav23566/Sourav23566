<!DOCTYPE html>
<html>
<head>
  <title>E-commerce - Home</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>

  <style>
     html, body {
      height: 100%;
      margin: 0;
    }
    body {
      background-color: #f4f6f9;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
       display: flex;
      flex-direction: column;
      min-height: 100vh; 
      
    }

    main {
      flex: 1; 
    }
    h1 {
      margin: 40px 0;
      text-align: center;
      font-weight: 700;
      color: #222;
    }

    /*  Navbar */
    .navbar {
      background: linear-gradient(90deg, #0d6efd, #071488ff);
      box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    }
    .navbar-brand {
      font-weight: 700;
      font-size: 22px;
      letter-spacing: 1px;
    }
    .nav-link {
      font-weight: 500;
      transition: color 0.3s;
    }
    .nav-link:hover {
      color: #ffc107 !important;
    }
    .navbar-text {
  font-size: 16px;
  font-weight: 600;
  color: #fff;             
  background: rgba(255,255,255,0.15);
  padding: 5px 12px;
  border-radius: 8px;
}


 
    #productList {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 25px;
    }

   
    .product-card {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.3s ease-in-out;
      min-height: 380px;
    }
    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }
    .product-card img {
      width: 100%;
      height: 180px;              
      object-fit: contain;       
      border-radius: 8px;
      margin-bottom: 15px;
      background: #f8f9fa;
      padding: 8px;
    }
    .product-card h4 {
      font-size: 18px;
      font-weight: 600;
      color: #222;
      margin-bottom: 8px;
    }
    .product-card p {
      font-size: 14px;
      color: #666;
      min-height: 40px;
    }
    .product-price {
      font-size: 16px;
      font-weight: bold;
      color: #28a745;
      margin: 10px 0;
    }
    .product-card .btn {
      border-radius: 8px;
      padding: 8px 16px;
    }

   
    #productDetails {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      margin: 20px auto;
      max-width: 1000px;
      display: none;
    }
    .details-container {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      align-items: center;
    }
    .details-container img {
      width: 100%;
      max-width: 400px;
      height: 300px;             
      object-fit: contain;
      border-radius: 10px;
      background: #f8f9fa;
      padding: 10px;
    }
    .details-info {
      flex: 1;
    }
    .details-info h2 {
      font-weight: 700;
      margin-bottom: 15px;
    }
    .details-info p {
      font-size: 15px;
      color: #444;
      margin-bottom: 10px;
    }
    .details-price {
      font-size: 20px;
      font-weight: bold;
      color: #28a745;
      margin: 15px 0;
    }
    .action-btns button {
      margin-right: 10px;
      border-radius: 8px;
    }
    #backBtn {
      margin-top: 25px;
      padding: 10px 20px;
      background: #6c757d;
      border: none;
      color: #fff;
      border-radius: 6px;
      font-weight: 500;
      transition: 0.3s;
    }
    #backBtn:hover {
      background: #5a6268;
    }
     footer {
    background: linear-gradient(90deg, #0d6efd, #071488ff);
      color: #fff;
      text-align: center;
      padding: 10px 0;
    }
  </style>
</head>
<body>


  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="#">E-Shop</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" 
      data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" 
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home</a>
        </li>
      </ul>
<form class="form-inline my-2 my-lg-0" method="post" onsubmit="return true;">
 <input type="text" id="searchInput" class="form-control mr-2" placeholder="Search...">

  <button id="searchBtn" class="btn btn-success my-2 my-sm-0">Search</button>
</form>
      
       

 
      <form class="form-inline my-2 my-lg-0 ml-2">
   <span class="navbar-text text-light font-weight-bold mr-3">
     👋 Hello, <?= session()->get('name'); ?>!
   </span>
   <a href="<?= base_url('/logout'); ?>" class="btn btn-danger my-2 my-sm-0">Logout</a>
</form>
    </div>
  </nav>


  <div class="container">
    <h1>Our Products</h1>
    <div id="productList"></div>
    <div id="productDetails"></div>
  </div>

  
  
  <script>
    $(document).ready(function(){
  fetchProducts(); // Fetch all products initially

  // Function to fetch all products
  function fetchProducts(keyword = '') {
    $.ajax({
      url: "http://localhost:8080/products/fetchAll",
      type: "GET",
      data: { search: keyword }, // Send the keyword if any
      dataType: "json",  
      success:function(data){
        let html = "";
        if(data.products && data.products.length > 0){
          data.products.forEach(function(p){
            html +=`
              <div class="product-card">
                ${p.image 
                    ? `<img src="/uploads/${p.image}" alt="${p.pro_name}">` 
                    : `<img src="https://via.placeholder.com/200x180?text=No+Image" alt="No Image">`}
                <h4>${p.pro_name}</h4>
                <p>${p.pro_desc}</p>
                <div class="product-price">₹${p.price}</div>
                <button class="btn btn-primary viewBtn" data-id="${p.pro_id}">
                  View Details
                </button>
              </div>`;
          });
        } else {
          html = "<p class='text-center'>No products found</p>";
        }
        $("#productList").html(html);
      }
    });
  }

  // Trigger search when search button is clicked
  $("#searchBtn").on("click", function(e) {
    e.preventDefault(); // Prevent form submission
    const keyword = $("#searchInput").val().trim(); // Get the search term
    fetchProducts(keyword); // Fetch products based on the search keyword
  });

      
      $(document).on("click", ".viewBtn", function(){
        let id = $(this).data("id");
        $.ajax({
          url: "/products/fetchOne/" + id,
          type: "GET",
          success: function(p){
            if(p){
              let details = `
                <div class="details-container">
                  ${p.image 
                    ? `<img src="/uploads/${p.image}" alt="${p.pro_name}">` 
                    : `<img src="https://via.placeholder.com/400x300?text=No+Image">`}
                  <div class="details-info">
                    <h2>${p.pro_name}</h2>
                    <p>${p.pro_desc}</p>
                    <div class="details-price">₹${p.price}</div>
                    <div class="action-btns">
                      <button class="btn btn-success">Add to Cart</button>
                      <button class="btn btn-warning">Buy Now</button>
                    </div>
                  </div>
                </div>
                <button id="backBtn">← Back to list</button>
              `;
              $("#productDetails").html(details).show();
              $("#productList").hide();
            }
          }
        });
      });

  
      $(document).on("click", "#backBtn", function(){
        $("#productDetails").hide().html(""); 
        $("#productList").show();
      });
    });
  </script>

  <footer class="footer py-3 text-white" style="background: linear-gradient(90deg, #0d6efd, #6610f2); margin-top:40px;">
    <div class="container text-center">
      <small>© 2025 <strong>E-Shop</strong>. All Rights Reserved.</small>
    </div>
  </footer>
</body>
</html>
