<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup</title>

  <!-- Bootstrap 4 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <style>
    body {
      background-color: #f4f7fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    
    .navbar {
      background: linear-gradient(90deg, #0d6efd, #071488ff);
      box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    }
    .navbar-brand {
      font-weight: 700;
      font-size: 22px;
      letter-spacing: 1px;
    }
    .nav-link {
      font-weight: 500;
      transition: color 0.3s;
    }
    .nav-link:hover {
      color: #ffc107 !important;
    }

    
    .signup-container {
      max-width: 450px;
      margin: 70px auto;
      background-color: #fff;
      padding: 35px;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    }

    .signup-container h2 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: 700;
      color: #333;
    }

    .form-group label {
      font-weight: 500;
      color: #444;
    }

    .form-control {
      border-radius: 8px;
      padding: 10px;
    }

    .btn-primary {
      border-radius: 8px;
      padding: 10px;
      font-weight: 500;
      background: #0d6efd;
      border: none;
      transition: 0.3s;
    }
    .btn-primary:hover {
      background: #0b5ed7;
    }

    .alert {
      border-radius: 8px;
      font-size: 14px;
    }

    p.text-center {
      margin-top: 15px;
      font-size: 14px;
    }
    p.text-center a {
      font-weight: 600;
      color: #40069eff;
      text-decoration: none;
    }
    p.text-center a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  

<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#">E-Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" 
          data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" 
          aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <!-- <a class="nav-link" href="<?= site_url('/') ?>">Home</a> -->
      </li>
    </ul>
  
  </div>
</nav>


<div class="signup-container">
  <h2>Signup</h2>
  
  <?php
    $session = \Config\Services::session();
    $validation = session()->getFlashdata('validation');
    if (isset($validation)) {
      echo '<div class="alert alert-danger">' . $validation->listErrors() . '</div>';
    }
    $message = $session->getFlashdata('message');
    if ($message == "signup_success") {
      echo '<div class="alert alert-success">Signup successfully completed!</div>';
    } elseif ($message == "signup_error") {
      echo '<div class="alert alert-danger">Signup failed. Please try again.</div>';
    }
  ?>

  <form method="post" action="<?= site_url('signup/submit') ?>" novalidate>
    <div class="form-group">
      <label>Name</label>
      <input type="text" name="name" class="form-control" value="<?= old('name') ?>" required placeholder="Enter your name"autocomplete="off">
    </div>

    <div class="form-group">
      <label>Email</label>
      <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required placeholder="Enter your email" autocomplete="off">
    </div>

    <div class="form-group">
      <label>Mobile</label>
      <input type="text" name="mobile" class="form-control" value="<?= old('mobile') ?>" required placeholder="Enter your mobile" autocomplete="off">
    </div>

    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" class="form-control" required placeholder="Enter your password">
    </div>

    <button type="submit" class="btn btn-primary btn-block">Signup</button>
  </form>

  <p class="text-center">
    Already have an account? <a href="<?= site_url('login') ?>">Login</a>
  </p>
</div>

</body>
</html>
