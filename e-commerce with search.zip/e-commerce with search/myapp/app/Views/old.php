<!DOCTYPE html>
<html>
<head>
    <title> - Home</title>
</head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">e-commerce</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
 </li>

</ul>

 <form class="form-inline my-2 my-lg-2">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
    <form class="form-inline my-2 my-lg-0  ml-2">
      <!-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"> -->
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit"><a href="<?= base_url('/logout'); ?>" class="text-reset text-decoration-none">Logout</a></button>
    </form>
  </div>
</nav>
<div class="container">
    <h1>Our products</h1>
    <div id="productList"></div>
<div class="card">
    <div id="productDetails"></div>
    <script>
      $(document).ready(function(){
        fetchProducts();
          function fetchProducts(){
        $.ajax({
         url:"http://localhost:8080/products/fetchAll",
          type:"GET",
          dataType:"json",  
          success:function(data){
            let html="";
            if(data.products && data.products.length>0){
              data.products.forEach(function(p){
                html +=`
                <div class="product-card">
                            <h4>${p.pro_name}</h4>
                            <p>${p.pro_desc}</p>
                            <p><strong>₹${p.price}</strong></p>
                            ${p.image 
                                ? `<img src="/uploads/${p.image}" width="150">` 
                                : `<p>No image</p>`}
                            <br>
                            <button class="btn btn-primary viewBtn" data-id="${p.pro_id}">
                                View Details
                            </button>
                `;

              });
              
              
         }else{
          html="<p>No products available</p>";
         }
         $("#productList").html(html);
        }
        });
      }
  




        $(document).on("click", ".viewBtn", function(){
        let id = $(this).data("id");

        $.ajax({
            url: "/products/fetchOne/" + id,
            type: "GET",
            success: function(p){
                if(p){
                    let details = `
                      <h2>${p.pro_name}</h2>
                      <p>${p.pro_desc}</p>
                      <p><strong>Price: ₹${p.price}</strong></p>
                      ${p.image ? `<img src="/uploads/${p.image}" width="300">` : `<p>No image</p>`}
                      <br><br><button id="backBtn">← Back to list</button>
                    `;
                    $("#productDetails").html(details).show();
                    $("#productList").hide(); // hide list
                }
            }
        });
    });

    // 🔹 Back button (return to product list)
    $(document).on("click", "#backBtn", function(){
        $("#productDetails").hide().html(""); 
        $("#productList").show();
    });

});

    
    </script>
</div>
</div>

</body>
</html>








  <?php
   if (!empty($products)): ?>
   <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-4">
                <div class="card">
                    <img src="<?= base_url('uploads/' . $product['image']) ?>" class="card-img-top" alt="<?= esc($product['pro_name']) ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= esc($product['pro_name']) ?></h5>
                        <p class="card-text"><?= esc($product['pro_desc']) ?></p>
                        <a href="<?= site_url('product/' . $product['pro_id']) ?>" class="btn btn-primary">View Product</a>
                         <button class="btn btn-success">Add to Cart</button>
                      <button class="btn btn-warning">Buy Now</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p>No products found matching your search criteria.</p>
<?php endif; ?>
  
























<!-- 
     <h1>Welcome to the <?= session()->get('name'); ?></h1>

    <p>Hello, <?= session()->get('name'); ?>!</p>

    <p>Your email: <?= session()->get('email'); ?></p>

    <a href="<?= base_url('/logout'); ?>">Logout</a> -->

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup</title>

  <!-- Bootstrap 4 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f4f7fa;
    }

    .container {
      max-width: 450px;
      margin-top: 60px;
      background-color: #cfdbe7;
      padding: 30px 20px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .scrollable {
      max-height: 300px;
      overflow-y: auto;
      padding-right: 10px;
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .alert {
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">e-commerce</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
    
     
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div class="container">
  <h2>Signup</h2>
<?php
   $session = \Config\Services::session();
    $message = $session->getFlashdata('message');
  $validation = session()->getFlashdata('validation');
    if (isset($validation)) {
      echo '<div class="alert alert-danger">' . $validation->listErrors() . '</div>';
    }
?>
  <div class="scrollable">
       

    <form method="post" action="<?= site_url('signup/submit') ?>" novalidate>
   
      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?= old('name') ?>" required>
      </div>

      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required>
      </div>

      <div class="form-group">
        <label>Mobile</label>
        <input type="mobile" name="mobile" class="form-control" value="<?= old('mobile') ?>" required>
      </div>

      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <button type="submit" class="btn btn-outline-primary btn-block">Submit</button>
    </form>

    <p class="text-center mt-3">
      Already have an account? <a href="<?= site_url('login') ?>">Login</a>
    </p>
  </div>
</div>

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>

  <!-- Bootstrap 4 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f4f7fa;
    }

    .container {
      max-width: 450px;
      margin-top: 60px;
      background-color: #cfdbe7;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .alert {
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">e-commerce</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
    
     
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div class="container">
  <h2>Login</h2>

  <?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
      <?= session()->getFlashdata('error') ?>
    </div>
  <?php endif; ?>

  <?php
    $session = \Config\Services::session();
    $message = $session->getFlashdata('message');

    if ($message == "signup_success") {
      echo '<div class="alert alert-success">Signup successfully completed!</div>';
    } elseif ($message == "signup_error") {
      echo '<div class="alert alert-danger">Signup failed. Please try again.</div>';
    }

  
  ?>

  <form method="post" action="<?= site_url('login/auth') ?>" novalidate>
  
    <div class="form-group">
      <label>Username</label>
      <input type="text" name="email" class="form-control" required placeholder="Enter username">
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" class="form-control" required placeholder="Enter password">
    </div>
    <button type="submit" class="btn btn-primary btn-block">Login</button>
    <p class="text-center mt-3">
      Don't have an account? <a href="<?= site_url('/') ?>">Sign up</a>
    </p>
  </form>
</div>

</body>
</html>











public function search(){
   $keyword = $this->request->getGet('keyword');
   $model = new ProductModel();

   if(!empty($keyword)){
   $data['products']=$model->search($keyword);
   }else{
    $data['products'] = [];
   }
// return $this->response->setJSON(['products' => $data]);
//    return view('home',$data);
return view('pro_card', $data);
   
}
  public function search($keyword){
         if (empty($keyword)) {
        return [];
    }
        return $this->like('pro_name',$keyword)
                     ->orLike('pro_desc',$keyword)
                     ->findAll();
    }



    <script>
  $(document).ready(function () {
  $('#searchForm').submit(function (e) {
    e.preventDefault();

    let keyword = $('#searchInput').val().trim();

    $.ajax({
      url: "<?= site_url('home/search') ?>",
      type: "GET",
      data: { keyword: keyword },
      success: function (html) {
        $('#productList').html(html); 
      },
      error: function () {
        $('#productList').html("<p class='text-danger'>Search failed. Try again.</p>");
      }
    });
  });
});

  </script>



search:<?php if (isset($products) && count($products) > 0): ?>
  <div id="productList">
    <?php foreach ($products as $p): ?>
      <div class="product-card">
        <?php if ($p['image']): ?>
          <img src="/uploads/<?= esc($p['image']) ?>" alt="<?= esc($p['pro_name']) ?>">
        <?php else: ?>
          <img src="https://via.placeholder.com/200x180?text=No+Image" alt="No Image">
        <?php endif; ?>
        <h4><?= esc($p['pro_name']) ?></h4>
        <p><?= esc($p['pro_desc']) ?></p>
        <div class="product-price">₹<?= esc($p['price']) ?></div>
        <button class="btn btn-primary viewBtn" data-id="<?= esc($p['pro_id']) ?>">View Details</button>
      </div>
    <?php endforeach; ?>
  </div>
<?php else: ?>
  <p class="text-center">No products found.</p>
<?php endif; ?>

// $(document).ready(function(){
    //   fetchProducts();

    //   function fetchProducts(){
    //     $.ajax({
    //       url:"http://localhost:8080/products/fetchAll",
    //       type:"GET",
    //       dataType:"json",  
    //       success:function(data){
    //         let html="";
    //         if(data.products && data.products.length>0){
    //           data.products.forEach(function(p){
    //             html +=`
    //               <div class="product-card">
    //                 ${p.image 
    //                     ? `<img src="/uploads/${p.image}" alt="${p.pro_name}">` 
    //                     : `<img src="https://via.placeholder.com/200x180?text=No+Image" alt="No Image">`}
    //                 <h4>${p.pro_name}</h4>
    //                 <p>${p.pro_desc}</p>
    //                 <div class="product-price">₹${p.price}</div>
    //                 <button class="btn btn-primary viewBtn" data-id="${p.pro_id}">
    //                   View Details
    //                 </button>
    //               </div>`;
    //           });
    //         } else {
    //           html="<p class='text-center'>No products available</p>";
    //         }
    //         $("#productList").html(html);
    //       }
    //     });
    //   }