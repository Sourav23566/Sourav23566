<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>

  <!-- Bootstrap 4 CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
  <style>
    body {
      background-color: #f4f7fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    
    .navbar {
      background: linear-gradient(90deg, #0d6efd, #071488ff);
      box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    }
    .navbar-brand {
      font-weight: 700;
      font-size: 22px;
      letter-spacing: 1px;
    }
    .nav-link {
      font-weight: 500;
      transition: color 0.3s;
    }
    .nav-link:hover {
      color: #ffc107 !important;
    }

   
    .login-container {
      max-width: 450px;
      margin: 70px auto;
      background-color: #fff;
      padding: 35px;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    }

    .login-container h2 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: 700;
      color: #333;
    }

    .form-group label {
      font-weight: 500;
      color: #444;
    }

    .form-control {
      border-radius: 8px;
      padding: 10px;
    }

    .btn-primary {
      border-radius: 8px;
      padding: 10px;
      font-weight: 500;
      background: #0d6efd;
      border: none;
      transition: 0.3s;
    }
    .btn-primary:hover {
      background: #0b5ed7;
    }

    .alert {
      border-radius: 8px;
      font-size: 14px;
    }

    p.text-center {
      margin-top: 15px;
      font-size: 14px;
    }
    p.text-center a {
      font-weight: 600;
      color: #40069eff;
      text-decoration: none;
    }
    p.text-center a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#">E-Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        
      </li>
    </ul>
    
  </div>
</nav>


<div class="login-container">
  <h2>Login</h2>

  <?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
      <?= session()->getFlashdata('error') ?>
    </div>
  <?php endif; ?>

  <?php
    $session = \Config\Services::session();
    $message = $session->getFlashdata('message');

    if ($message == "signup_success") {
      echo '<div class="alert alert-success">Signup successfully completed!</div>';
    } elseif ($message == "signup_error") {
      echo '<div class="alert alert-danger">Signup failed. Please try again.</div>';
    }
  ?>

  <form method="post" action="<?= site_url('login/auth') ?>" novalidate>
    <div class="form-group">
      <label>Username</label>
      <input type="text" name="email" class="form-control" required placeholder="Enter username" autocomplete="off">
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" class="form-control" required placeholder="Enter password">
    </div>
    <button type="submit" class="btn btn-primary btn-block">Login</button>
    <p class="text-center">
      Don't have an account? <a href="<?= site_url('/') ?>">Sign up</a>
    </p>
  </form>
</div>

</body>
</html>
